﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebParser.Services
{
    public interface IMyParseWeb
    {
        List<string> ExtractContent(string url);
    }
}
